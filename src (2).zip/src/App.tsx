import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import MainPage from "./pages/MainPage";
import CreateList from "./pages/CreateList";
import GlobalStyle from "./globalStyles";

function App() {
  return (
    <Router>
      <GlobalStyle />
      <Routes>
        <Route path="/" element={<MainPage />} />
        <Route path="/create-list" element={<CreateList />} />
        <Route path="/my-wishlists"></Route>
      </Routes>
    </Router>
  );
}

export default App;
