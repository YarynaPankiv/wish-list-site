export default function MyWishLists() {
  return <div></div>;
}
