import { useState } from "react";
import styled from "styled-components";
import CreateWish from "./CreateWish";
import { Wish } from "../interfaces";

interface WishesGridProps {
  setWishes: React.Dispatch<React.SetStateAction<Wish[]>>;
}

export default function WishesGrid({ setWishes }: WishesGridProps) {
  const [isPlusClicked, setIsPlusClicked] = useState<boolean>(false);

  const handleOnPlusClick = () => {
    if (!isPlusClicked) {
      setIsPlusClicked(true);
    }

    console.log("ekfmwekfm");
  };

  const addWish = (newWish: Wish) => {
    setWishes((prevWishes) => [...prevWishes, newWish]);
    console.log(newWish);
  };

  return (
    <Container>
      {isPlusClicked && <CreateWish addWish={addWish} />}
      <StyledP2>Your wishes</StyledP2>
      <AddWishRect onClick={handleOnPlusClick} isClickable={!isPlusClicked}>
        <PlusElement1 />
        <PlusElement2 />
      </AddWishRect>
    </Container>
  );
}

const Container = styled.div`
  background-color: #e5d9f2;
  padding: 30px;
  border-radius: 15px;
  min-width: 580px;
`;

interface AddWishRectProps {
  isClickable: boolean;
}

const AddWishRect = styled.div<AddWishRectProps>`
  background-color: aliceblue;
  height: 150px;
  width: 150px;
  border-radius: 30px;
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: ${(props) => (props.isClickable ? "pointer" : "not-allowed")};
  transition: transform 0.3s ease, color 0.3s ease, border-color 0.3s ease;
  box-shadow: rgba(0, 0, 0, 0.1) 0px 20px 25px -5px,
    rgba(0, 0, 0, 0.04) 0px 10px 10px -5px;

  &:hover {
    border-color: ${(props) => (props.isClickable ? "#a871e0" : "#ccc")};
    color: ${(props) => (props.isClickable ? "#a871e0" : "#ccc")};
    transform: ${(props) => (props.isClickable ? "scale(1.05)" : "none")};
  }
`;

const PlusElement1 = styled.div`
  height: 100px;
  width: 13px;
  background-color: #a5cef1;
  border-radius: 20px;
  position: absolute;
`;

const PlusElement2 = styled.div`
  height: 13px;
  width: 100px;
  background-color: #a5cef1;
  border-radius: 20px;
  position: absolute;
`;

const StyledP2 = styled.p`
  font-size: 25px;
  font-weight: 700;
  margin-top: 5px;
  text-align: center;
`;
