import styled from "styled-components";
import Header from "../components/Header";
import WishesGrid from "../components/WishesGrid";
import { useState } from "react";
import { UseSelector, useDispatch, useSelector } from "react-redux";
import { RootState } from "../redux/store";
import { addToLists } from "../redux/wishlistsSlice";
import { Wish, WishList } from "../interfaces";

export default function CreateList() {
  const [listName, setListName] = useState<string>("");
  const [wishes, setWishes] = useState<Wish[]>([]);

  const wishlists = useSelector((state: RootState) => state.wishlists.value);
  const dispatch = useDispatch();

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setListName(e.target.value);
  };

  const handleCreateWishList = () => {
    const newWishList: WishList = {
      name: listName,
      wishes: wishes,
    };
    dispatch(addToLists(newWishList));
    console.log(newWishList);
  };

  const handleAddWish = (newWish: Wish) => {
    setWishes([...wishes, newWish]);
  };

  return (
    <Container>
      <Header />
      <StyledP>Create Your Wish List</StyledP>
      <Form>
        <InputNameDiv>
          <Label htmlFor="nameInput">Give your Wish List a name</Label>
          <InputName
            id="nameInput"
            value={listName}
            onChange={handleNameChange}
            placeholder="Enter wish list name"
          />
        </InputNameDiv>

        <WishesGrid setWishes={setWishes} />

        <SubmitButton onClick={handleCreateWishList}>
          Create Wish List
        </SubmitButton>
      </Form>
    </Container>
  );
}

const Container = styled.div``;

const StyledP = styled.p`
  font-family: "Exo", system-ui;
  font-size: 30px;
  font-weight: 500;
  text-align: center;
`;

const Form = styled.form`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  padding: 0 20px;
  gap: 20px;
`;

const InputNameDiv = styled.div`
  display: flex;
  gap: 20px;
  align-items: center;
  background-color: #e5d9f2;
  padding: 20px 50px;
  border-radius: 15px;
`;

const InputName = styled.input`
  padding: 8px 15px;
  font-size: 20px;
  background-color: #f5efff;
  border: 2px solid #cdc1ff;
  border-radius: 20px;

  &::placeholder {
    font-size: 15px;
    color: #bbb;
  }
`;

const Label = styled.label`
  font-size: 20px;
`;

const SubmitButton = styled.button`
  padding: 10px 20px;
  font-size: 16px;
  color: white;
  background-color: #6a67ce;
  border: none;
  border-radius: 10px;
  cursor: pointer;

  &:hover {
    background-color: #5754a0;
  }
`;
