import { configureStore } from "@reduxjs/toolkit";
import wishlistsReducer from "./wishlistsSlice";

const store = configureStore({
  reducer: {
    wishlists: wishlistsReducer,
  },
});

export default store;

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
